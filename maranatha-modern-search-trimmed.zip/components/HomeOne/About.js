/* eslint-disable @next/next/no-img-element */
import React from "react";
import Link from "next/link";

const About = () => {
  return (
    
   
   

   
  

   <>
    <section className="about-area ptb-110">
        <div className="container">


<div id="preloader">
    <div id="status" class="la-ball-triangle-path">
        <div></div>
        <div></div>
        <div></div>
    </div>
</div>

<div class="page-border" data-wow-duration="0.7s" data-wow-delay="0.2s">
    <div class="top-border wow fadeInDown animated" style="visibility: visible; animation-name: fadeInDown;"></div>
    <div class="right-border wow fadeInRight animated" style="visibility: visible; animation-name: fadeInRight;"></div>
    <div class="bottom-border wow fadeInUp animated" style="visibility: visible; animation-name: fadeInUp;"></div>
    <div class="left-border wow fadeInLeft animated" style="visibility: visible; animation-name: fadeInLeft;"></div>
</div>


     
        <div id="banner-content" class="row clearfix">

            <div class="col-38">

                <div class="section-heading">
                    <h1>A FREE AND SIMPLE LANDING PAGE</h1>
                    <h2>Namari is a free landing page template you can use for your projects. It is free to use for your
                        personal and commercial projects, enjoy!</h2>
                </div>

                <a href="#" class="button">START CREATING TODAY</a>
                

            </div>

        </div>
    

   
    <main id="content">

      
        <section id="about" class="introduction scrollto">

            <div class="row clearfix">

                <div class="col-3">
                    <div class="section-heading">
                        <h3>SUCCESS</h3>
                        <h2 class="section-title">How We Help You To Sell Your Product</h2>
                        <p class="section-subtitle">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
                            eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam!</p>
                    </div>

                </div>

                <div class="col-2-3">

                    <div class="col-2 icon-block icon-top wow fadeInUp" data-wow-delay="0.1s">
                
                        <div class="icon">
                            <i class="fa fa-html5 fa-2x"></i>
                        </div>
                    
                        <div class="icon-block-description">
                            <h4>HTML5 &amp; CSS3</h4>
                            <p>Has ne tritani atomorum conclusionemque, in dolorum volumus cotidieque eum. At vis choro
                                neglegentur iudico</p>
                        </div>
                    </div>
                  
                    <div class="col-2 icon-block icon-top wow fadeInUp" data-wow-delay="0.3s">
                      
                        <div class="icon">
                            <i class="fa fa-bolt fa-2x"></i>
                        </div>
                      
                        <div class="icon-block-description">
                            <h4>Easy to Use</h4>
                            <p>Cu vero ipsum vim, doctus facilisi sea in. Eam ex falli honestatis repudiandae, sit
                                detracto mediocrem disputationi</p>
                        </div>
                    </div>
                 
                    <div class="col-2 icon-block icon-top wow fadeInUp" data-wow-delay="0.5s">
                     
                        <div class="icon">
                            <i class="fa fa-tablet fa-2x"></i>
                        </div>
                 
                        <div class="icon-block-description">
                            <h4>Fully Responsive</h4>
                            <p>Id porro tritani recusabo usu, eum intellegam consequuntur et. Fugit debet ea sit, an pro
                                nemore vivendum</p>
                        </div>
                    </div>
                   

                   
                    <div class="col-2 icon-block icon-top wow fadeInUp" data-wow-delay="0.5s">
                     
                        <div class="icon">
                            <i class="fa fa-rocket fa-2x"></i>
                        </div>
                
                        <div class="icon-block-description">
                            <h4>Parallax Effect</h4>
                            <p>Id porro tritani recusabo usu, eum intellegam consequuntur et. Fugit debet ea sit, an pro
                                nemore vivendum</p>
                        </div>
                    </div>
              

                </div>

            </div>


        </section>
     


        <aside id="gallery" class="row text-center scrollto clearfix" data-featherlight-gallery
                 data-featherlight-filter="a">

                <a href="images/gallery-images/gallery-image-1.jpg" data-featherlight="image" class="col-3 wow fadeIn"
                   data-wow-delay="0.1s"><img src="images/gallery-images/gallery-image-1.jpg" alt="Landing Page"/></a>
                <a href="images/gallery-images/gallery-image-2.jpg" data-featherlight="image" class="col-3 wow fadeIn"
                   data-wow-delay="0.3s"><img src="images/gallery-images/gallery-image-2.jpg" alt="Landing Page"/></a>
                <a href="images/gallery-images/gallery-image-3.jpg" data-featherlight="image" class="col-3 wow fadeIn"
                   data-wow-delay="0.5s"><img src="images/gallery-images/gallery-image-3.jpg" alt="Landing Page"/></a>
                <a href="images/gallery-images/gallery-image-4.jpg" data-featherlight="image" class="col-3 wow fadeIn"
                   data-wow-delay="1.1s"><img src="images/gallery-images/gallery-image-4.jpg" alt="Landing Page"/></a>
                <a href="images/gallery-images/gallery-image-5.jpg" data-featherlight="image" class="col-3 wow fadeIn"
                   data-wow-delay="0.9s"><img src="images/gallery-images/gallery-image-5.jpg" alt="Landing Page"/></a>
                <a href="images/gallery-images/gallery-image-6.jpg" data-featherlight="image" class="col-3 wow fadeIn"
                   data-wow-delay="0.7s"><img src="images/gallery-images/gallery-image-6.jpg" alt="Landing Page"/></a>

        </aside>
      
        <div id="services" class="scrollto clearfix">

            <div class="row no-padding-bottom clearfix">


             
                <div class="col-3">
                   
                    <blockquote class="testimonial text-right bigtest">
                        <q>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut
                            labore
                            et dolore magna aliqua</q>
                        <footer>— John Doe, Happy Customer</footer>
                    </blockquote>
                  

                </div>
              
                <div class="col-3">
                    <div class="section-heading">
                        <h3>BELIEVING</h3>
                        <h2 class="section-title">Focusing On What Matters Most</h2>
                        <p class="section-subtitle">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
                            eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam!</p>
                    </div>
                    <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium,
                        totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae
                        dicta sunt explicabo.
                    </p>
                    <p>
                        Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia
                        consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt.
                        Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet!
                    </p>
                    <a href="#" data-videoid="UYJ5IjBRlW8" data-videosite="youtube" class="button video link-lightbox">
                        WATCH VIDEO <i class="fa fa-play" aria-hidden="true"></i>
                    </a>
                </div>
           

                <div class="col-3">
                    <img src="images/dancer.jpg" alt="Dancer"/>
                </div>

            </div>


        </div>
       
        <aside id="testimonials" class="scrollto text-center" data-enllax-ratio=".2">

            <div class="row clearfix">

                <div class="section-heading">
                    <h3>FEEDBACK</h3>
                    <h2 class="section-title">What our customers are saying</h2>
                </div>

                <blockquote class="col-3 testimonial classic">
                    <img src="images/user-images/user-1.jpg" alt="User"/>
                    <q>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut
                        labore
                        et dolore magna aliqua</q>
                    <footer>John Doe - Happy Customer</footer>
                </blockquote>
               

            
                <blockquote class="col-3 testimonial classic">
                    <img src="images/user-images/user-2.jpg" alt="User"/>
                    <q>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut
                        labore
                        et dolore magna aliqua</q>
                    <footer>Roslyn Doe - Happy Customer</footer>
                </blockquote>
               
                <blockquote class="col-3 testimonial classic">
                    <img src="images/user-images/user-3.jpg" alt="User"/>
                    <q>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut
                        labore
                        et dolore magna aliqua</q>
                    <footer>Thomas Doe - Happy Customer</footer>
                </blockquote>
        

            </div>

        </aside>
    
        <section id="clients" class="scrollto clearfix">
            <div class="row clearfix">

                <div class="col-3">

                    <div class="section-heading">
                        <h3>TRUST</h3>
                        <h2 class="section-title">Companies who use our services</h2>
                        <p class="section-subtitle">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
                            eiusmod
                            tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam!</p>
                    </div>

                </div>

                <div class="col-2-3">

                    <a href="#" class="col-3">
                        <img src="images/company-images/company-logo1.png" alt="Company"/>
                        <div class="client-overlay"><span>Tree</span></div>
                    </a>
                    <a href="#" class="col-3">
                        <img src="images/company-images/company-logo2.png" alt="Company"/>
                        <div class="client-overlay"><span>Fingerprint</span></div>
                    </a>
                    <a href="#" class="col-3">
                        <img src="images/company-images/company-logo3.png" alt="Company"/>
                        <div class="client-overlay"><span>The Man</span></div>
                    </a>
                    <a href="#" class="col-3">
                        <img src="images/company-images/company-logo4.png" alt="Company"/>
                        <div class="client-overlay"><span>Mustache</span></div>
                    </a>
                    <a href="#" class="col-3">
                        <img src="images/company-images/company-logo5.png" alt="Company"/>
                        <div class="client-overlay"><span>Goat</span></div>
                    </a>
                    <a href="#" class="col-3">
                        <img src="images/company-images/company-logo6.png" alt="Company"/>
                        <div class="client-overlay"><span>Justice</span></div>
                    </a>
                    <a href="#" class="col-3">
                        <img src="images/company-images/company-logo7.png" alt="Company"/>
                        <div class="client-overlay"><span>Ball</span></div>
                    </a>
                    <a href="#" class="col-3">
                        <img src="images/company-images/company-logo8.png" alt="Company"/>
                        <div class="client-overlay"><span>Cold</span></div>
                    </a>

                    <a href="#" class="col-3">
                        <img src="images/company-images/company-logo9.png" alt="Company"/>
                        <div class="client-overlay"><span>Cold</span></div>
                    </a>

                </div>

            </div>
        </section>
    
     

    </main>
 
    </div>
      </section>

      </>
  );
};

  

export default About;







     

